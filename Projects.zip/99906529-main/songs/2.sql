SELECT name from songs
ORDER BY tempo;