#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

bool check_key(string x);
//check if key valid
int main(int argc, string argv[])
{
    if((argc != 2) || !(check_key(argv[1])))
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }
    else
    {
    string text = get_string("plaintext: ");
    //convert key to integer
    int key = atoi(argv[1]);
    int l=strlen(text);
    printf("ciphertext: ");
    for(int i = 0; i < l; i++)
    {
        if(isalpha(text[i]))  //checkif text is alpha
        {
            if(isupper(text[i])) //check if charactar is capital
            {
                printf("%c",(((text[i]-'A'+key)%26)+'A')); //ceipher text
            }
            else
            {
                printf("%c",(((text[i]-'a'+key)%26)+'a'));
            }
        }
        else
        {
            printf("%c",text[i]);
        }
    }
    printf("\n");
    return 0;
    }
}
bool check_key(string x) // funtction to check if key is digit
{
    for(int j = 0 ; j < strlen(x) ; j++)
    {
        if(!isdigit(x[j]))
        {
            return false;
        }
    }
    return true;
}
